//
//  ViewController.swift
//  Timer
//
//  Created by Andrew Smailes on 24/04/2016.
//  Copyright © 2016 Delta Developers Team. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {
    
    @IBOutlet weak var minutesRemainingDisplay: NSTextField!
    
    @IBOutlet weak var secondsRemainingDisplay: NSTextField!
    
    @IBOutlet weak var centisecondRemainingDisplay: NSTextField!
    
    @IBOutlet weak var timerButton: NSButton!
    
    @IBOutlet weak var stopTimerButton: NSButton!
    
    @IBOutlet weak var secondsRequestedAmount: NSSlider!
    
    @IBOutlet weak var minutesRequestedAmount: NSSlider!
    
    var secondsRemaining = 0
    var minutesRemaining = 5
    var centisecondsRemaining = 0
    var timer = NSTimer()
    var timerStarted = false
    let timerEndSound = NSSound(named: "Airhorn-SoundBible.com-975027544.wav")
    let timerFinishedAlert = NSAlert()
    let timerStartAlert = NSAlert()
    
    @IBAction func timerStarted(sender: NSButton) {
        guard timerStarted == false else {
            timer.invalidate()
            timerButton.title = "Start"
            timerStarted = false
            return
        }
        runTimer()
    }
    
    @IBAction func timerStopped(sender: NSButton) {
        timerFinished()
    }
    
    @IBAction func minutesRequested(sender: AnyObject) {
        minutesRemaining = minutesRequestedAmount.integerValue
        minutesRemainingDisplay.stringValue = String(format: "%02d", minutesRemaining)
    }
    
    @IBAction func secondsRequested(sender: AnyObject) {
        secondsRemaining = secondsRequestedAmount.integerValue
        secondsRemainingDisplay.stringValue = String(format: "%02d", secondsRemaining)
    }
    
    override func viewWillAppear() {
        self.view.layer?.backgroundColor = NSColor.init(red: 0.14, green: 0.37, blue: 0.46, alpha: 1).CGColor
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.wantsLayer = true
        stopTimerButton.enabled = false
        userUpdate()
        timerFinishedAlert.messageText = "Timer finished!"
        timerFinishedAlert.informativeText = "The time is up..."
        timerFinishedAlert.icon = NSImage(named: "icon_nsalert_512x512@2x.png")
        timerStartAlert.messageText = "Incorrect Timer Input"
        timerStartAlert.informativeText = "You cannot start timing from 00:00."
        timerStartAlert.icon = NSImage(named: "icon_nsalert_512x512@2x.png")
    }

    override var representedObject: AnyObject? {
        didSet {
        }
    }
    
    func runTimer() {
        if secondsRemaining == 0 && minutesRemaining == 0 {
            timerStartAlert.runModal()
            return
        }
            timer = NSTimer.scheduledTimerWithTimeInterval(0.01, target: self, selector: #selector(ViewController.secondPassed), userInfo: nil, repeats: true)
            timerStarted = true
            minutesRequestedAmount.hidden = true
            secondsRequestedAmount.hidden = true
            timerButton.title = "Pause"
            stopTimerButton.enabled = true
        }

    func timerFinished() {
        timer.invalidate()
        timerStarted = false
        timerButton.title = "Start"
        minutesRequestedAmount.hidden = false
        secondsRequestedAmount.hidden = false
        centisecondsRemaining = 0
        secondsRemaining = secondsRequestedAmount.integerValue
        minutesRemaining = minutesRequestedAmount.integerValue
        userUpdate()
        stopTimerButton.enabled = false
    }
    
    func userUpdate() {
        minutesRemainingDisplay.stringValue = String(format: "%02d", minutesRemaining)
        secondsRemainingDisplay.stringValue = String(format: "%02d", secondsRemaining)
        centisecondRemainingDisplay.stringValue = String(format: "%02d", centisecondsRemaining)
    }
    
    func secondPassed() {
            if secondsRemaining == 0 && minutesRemaining == 0 && centisecondsRemaining == 0 {
                timerFinished()
                timerEndSound?.play()
                timerFinishedAlert.runModal()
                timerEndSound?.stop()
                return
            }
            else if secondsRemaining == 0 && centisecondsRemaining == 0 {
                centisecondsRemaining = 100
                secondsRemaining = 59
                minutesRemaining -= 1
            }
            else if centisecondsRemaining == 0 {
                centisecondsRemaining = 100
                secondsRemaining -= 1
            }
        centisecondsRemaining -= 1
        userUpdate()
    }
}