//
//  ViewController.swift
//  Timer
//
//  Created by Andrew Smailes on 24/04/2016.
//  Copyright © 2016 Delta Developers Team. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {
    var secondsRemaining = 0
    var minutesRemaining = 5
    var timer = NSTimer()
    var timerStarted = false
    let timerEndSound = NSSound(named: "Airhorn-SoundBible.com-975027544.wav")
    let timerFinishedAlert = NSAlert()
    let timerStartAlert = NSAlert()
    
    @IBOutlet weak var minutesRemainingDisplay: NSTextField!
    
    @IBOutlet weak var secondsRemainingDisplay: NSTextField!
    
    @IBOutlet weak var timerButton: NSButton!
    
    @IBOutlet weak var stopTimerButton: NSButton!
    
    @IBOutlet weak var secondsRequestedAmount: NSSlider!
    
    @IBOutlet weak var minutesRequestedAmount: NSSlider!
    
    @IBAction func timerStarted(sender: NSButton) {
        if timerStarted == false {
            runTimer()
        }
        else {
            timer.invalidate()
            timerButton.title = "Start"
            timerStarted = false
        }
    }
    
    @IBAction func timerStopped(sender: NSButton) {
        timerFinished()
    }
    
    @IBAction func minutesRequested(sender: AnyObject) {
        minutesRemaining = minutesRequestedAmount.integerValue
        minutesRemainingDisplay.stringValue = String(format: "%02d", minutesRemaining)
    }
    
    @IBAction func secondsRequested(sender: AnyObject) {
        secondsRemaining = secondsRequestedAmount.integerValue
        secondsRemainingDisplay.stringValue = String(format: "%02d", secondsRemaining)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        stopTimerButton.enabled = false
        secondsRemainingDisplay.stringValue = String(format: "%02d", secondsRemaining)
        minutesRemainingDisplay.stringValue = String(format: "%02d", minutesRemaining)
        timerFinishedAlert.messageText = "Timer finished!"
        timerFinishedAlert.informativeText = "Time is up!"
        timerFinishedAlert.icon = NSImage(named: "icon_nsalert_512x512@2x.png")
        timerStartAlert.messageText = "Incorrect Timer Input"
        timerStartAlert.informativeText = "You cannot start timing from 00:00."
        timerStartAlert.icon = NSImage(named: "icon_nsalert_512x512@2x.png")
    }

    override var representedObject: AnyObject? {
        didSet {
        }
    }
    
    func runTimer() {
        if secondsRemaining == 0 && minutesRemaining == 0 {
            timerStartAlert.runModal()
            return
        }
        else if secondsRemaining >= 0 {
            timer = NSTimer.scheduledTimerWithTimeInterval(1.0, target: self, selector: #selector(ViewController.secondPassed), userInfo: nil, repeats: true)
            timerStarted = true
            minutesRequestedAmount.hidden = true
            secondsRequestedAmount.hidden = true
            timerButton.title = "Pause"
            stopTimerButton.enabled = true
        }
    }
    
    func timerFinished() {
        timer.invalidate()
        timerStarted = false
        timerButton.title = "Start"
        minutesRequestedAmount.hidden = false
        secondsRequestedAmount.hidden = false
        minutesRemaining = minutesRequestedAmount.integerValue
        minutesRemainingDisplay.stringValue = String(format: "%02d", minutesRemaining)
        secondsRemaining = secondsRequestedAmount.integerValue
        secondsRemainingDisplay.stringValue = String(format: "%02d", secondsRemaining)
        stopTimerButton.enabled = false
    }
    
    func secondPassed() {
        if secondsRemaining == 0 && minutesRemaining == 0 {
            timerFinished()
            timerEndSound?.play()
            timerFinishedAlert.runModal()
            timerEndSound?.stop()
            return
        }
        else if secondsRemaining == 0 {
            secondsRemaining = 60
            minutesRemaining -= 1
        }
        secondsRemaining -= 1
        minutesRemainingDisplay.stringValue = String(format: "%02d", minutesRemaining)
        secondsRemainingDisplay.stringValue = String(format: "%02d", secondsRemaining)
    }
}